import asyncio
from datetime import datetime

from aiogram import Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from aiogram.contrib.middlewares.logging import LoggingMiddleware
from aiogram.utils import executor

import sqlite3

# Замените 'YOUR_BOT_TOKEN' на токен вашего бота
API_TOKEN = '7167165076:AAGTst5ecBmVmKVteyVeICzENrHmeH1CrwE'

bot = Bot(token=API_TOKEN)
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)
dp.middleware.setup(LoggingMiddleware())

def init_db():
    conn = sqlite3.connect('reminders.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS reminders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chat_id INTEGER NOT NULL,
            reminder_time TEXT NOT NULL,
            reminder_text TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

init_db()

class Form(StatesGroup):
    gender = State()
    age = State()
    height = State()
    weight = State()
    lifestyle = State()
    goal = State()
    reminder_time = State()
    reminder_text = State()
    delete_reminder_id = State()

# Создаем клавиатуру для выбора пола
gender_keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
gender_keyboard.add(KeyboardButton('Мужской'), KeyboardButton('Женский'))

# Создаем клавиатуру для выбора образа жизни
lifestyle_keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
lifestyle_keyboard.add(KeyboardButton('Сидячий'), KeyboardButton('Малоактивный'), KeyboardButton('Активный'), KeyboardButton('Очень активный'))

# Создаем клавиатуру для выбора цели
goal_keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
goal_keyboard.add(KeyboardButton('Сбросить вес'), KeyboardButton('Набрать вес'), KeyboardButton('Поддерживать вес'))

# Основное меню
main_menu_keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
main_menu_keyboard.add(KeyboardButton('Калькулятор БЖУ'), KeyboardButton('Напоминания'))

# Подменю "Напоминания"
reminders_menu_keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
reminders_menu_keyboard.add(KeyboardButton('Создать напоминание'), KeyboardButton('Просмотреть напоминания'))
reminders_menu_keyboard.add(KeyboardButton('Удалить напоминание'), KeyboardButton('Главное меню'))

# Клавиатура для отмены действия
cancel_keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
cancel_keyboard.add(KeyboardButton('/cancel'))

def add_reminder(chat_id: int, reminder_time: str, reminder_text: str):
    conn = sqlite3.connect('reminders.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO reminders (chat_id, reminder_time, reminder_text)
        VALUES (?, ?, ?)
    ''', (chat_id, reminder_time, reminder_text))
    conn.commit()
    conn.close()

def get_all_reminders():
    conn = sqlite3.connect('reminders.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM reminders')
    reminders = cursor.fetchall()
    conn.close()
    return reminders

def get_user_reminders(chat_id: int):
    conn = sqlite3.connect('reminders.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM reminders WHERE chat_id = ?', (chat_id,))
    reminders = cursor.fetchall()
    conn.close()
    return reminders

def delete_reminder(reminder_id: int) -> bool:
    conn = sqlite3.connect('reminders.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM reminders WHERE id = ?', (reminder_id,))
    conn.commit()
    deleted = cursor.rowcount > 0
    conn.close()
    return deleted

"""
def clear_db():
    conn = sqlite3.connect('reminders.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM reminders')     # Очистка БД
    conn.commit()
    conn.close()

clear_db()
"""

@dp.message_handler(commands=['start'])
async def send_welcome(message: types.Message):
    await message.reply("Добро пожаловать в telegram-bot'a 'Помощник по питанию' 👋\nЯ могу рассчитать норму БЖУ под твои цели 📝\nа также напомнить тебе о приеме пищи 🍎", reply_markup=main_menu_keyboard)

@dp.message_handler(commands=['cancel'], state='*')
async def cancel_action(message: types.Message, state: FSMContext):
    await state.finish()
    await message.reply("❌ Действие отменено. Возвращаюсь в главное меню.", reply_markup=main_menu_keyboard)

@dp.message_handler(lambda message: message.text == 'Калькулятор БЖУ')
async def ask_gender(message: types.Message):
    await Form.gender.set()
    await message.reply("Выберите ваш пол 🔍", reply_markup=gender_keyboard)

@dp.message_handler(lambda message: message.text == 'Напоминания')
async def reminders_menu(message: types.Message):
    await message.reply("Выберите действие с напоминаниями:", reply_markup=reminders_menu_keyboard)

# Обработчик для кнопки "Главное меню"
@dp.message_handler(lambda message: message.text == 'Главное меню')
async def main_menu(message: types.Message):
    await message.reply("Вы вернулись в главное меню.", reply_markup=main_menu_keyboard)

@dp.message_handler(lambda message: message.text == 'Создать напоминание')
async def ask_reminder_time(message: types.Message):
    await Form.reminder_time.set()
    await message.reply("Введите дату и время напоминания в формате YYYY-MM-DD HH:MM ⏰, например: '2024-06-14 15:00'", reply_markup=cancel_keyboard)

@dp.message_handler(lambda message: message.text == 'Просмотреть напоминания')
async def view_reminders(message: types.Message):
    reminders = get_user_reminders(message.chat.id)
    if not reminders:
        await message.reply("У вас нет установленных напоминаний.", reply_markup=reminders_menu_keyboard)
    else:
        reminders_text = "\n".join([f"ID {reminder[0]}: {reminder[2]} - {reminder[3]}" for reminder in reminders])
        await message.reply(f"Ваши напоминания:\n{reminders_text}", reply_markup=reminders_menu_keyboard)

@dp.message_handler(lambda message: message.text == 'Удалить напоминание')
async def delete_reminder_command(message: types.Message):
    await message.reply("Введите ID напоминания, которое вы хотите удалить:", reply_markup=cancel_keyboard)
    await Form.delete_reminder_id.set()  # Используем новое состояние

@dp.message_handler(lambda message: not message.text.isdigit(), state=Form.delete_reminder_id)
async def process_invalid_id(message: types.Message):
    await message.reply("ID должен быть числом. Попробуйте снова или введите /cancel для отмены.")

@dp.message_handler(lambda message: message.text.isdigit(), state=Form.delete_reminder_id)
async def delete_reminder_by_id(message: types.Message, state: FSMContext):
    reminder_id = int(message.text)
    if delete_reminder(reminder_id):
        await message.reply(f"Напоминание с ID {reminder_id} было удалено.", reply_markup=reminders_menu_keyboard)
    else:
        await message.reply(f"Напоминание с ID {reminder_id} не найдено.", reply_markup=reminders_menu_keyboard)
    await state.finish()

@dp.message_handler(state=Form.reminder_time)
async def process_reminder_time(message: types.Message, state: FSMContext):
    try:
        reminder_time = datetime.strptime(message.text, '%Y-%m-%d %H:%M')
        if reminder_time < datetime.now():
            await message.reply("❌ Время напоминания должно быть в будущем. Попробуйте снова:")
            return
        await state.update_data(reminder_time=reminder_time)
        await Form.next()
        await message.reply("Напишите, что вам нужно скушать в это время 🍜", reply_markup=cancel_keyboard)
    except ValueError:
        await message.reply("❌ Неправильный формат даты и времени. Введите в формате YYYY-MM-DD HH:MM")

@dp.message_handler(state=Form.reminder_text)
async def set_reminder(message: types.Message, state: FSMContext):
    reminder_text = message.text
    if len(reminder_text) > 50:
        await message.reply("Текст напоминания не должен превышать 50 символов. Пожалуйста, введите текст заново:")
        return
    await state.update_data(reminder_text=reminder_text)
    user_data = await state.get_data()
    reminder_time = user_data['reminder_time']
    reminder_text = user_data['reminder_text']

    # Сохраняем напоминание в базу данных
    add_reminder(message.chat.id, reminder_time.strftime('%Y-%m-%d %H:%M'), reminder_text)

    await message.reply(f"Напоминание установлено на {reminder_time.strftime('%Y-%m-%d %H:%M')} ✅\nТекст напоминания: {reminder_text}", reply_markup=main_menu_keyboard)
    await state.finish()


async def schedule_reminders():
    while True:
        reminders = get_all_reminders()
        for reminder in reminders:
            reminder_id, chat_id, reminder_time_str, reminder_text = reminder
            try:
                reminder_time = datetime.strptime(reminder_time_str, '%Y-%m-%d %H:%M')
                if reminder_time <= datetime.now():
                    await bot.send_message(chat_id, f"❗️ Напоминание на {reminder_time.strftime('%Y-%m-%d %H:%M')} ❗️ - {reminder_text}")
                    delete_reminder(reminder_id)
            except ValueError as e:
                print(f"Error parsing reminder time: {e}")
                delete_reminder(reminder_id)  # Удаляем некорректную запись
        await asyncio.sleep(60)  # Проверка каждые 60 секунд

@dp.message_handler(state=Form.gender)
async def process_gender(message: types.Message, state: FSMContext):
    if message.text not in ['Мужской', 'Женский']:
        await message.reply("❌ Пожалуйста, выберите пол, используя кнопки ниже.")
        return
    await state.update_data(gender=message.text)
    await Form.next()
    await message.reply("Введите ваш возраст:", reply_markup=cancel_keyboard)

@dp.message_handler(state=Form.age)
async def process_age(message: types.Message, state: FSMContext):
    if not message.text.isdigit() or not (10 <= int(message.text) <= 120):
        await message.reply("❌ Возраст должен быть числом от 10 до 120. Введите ваш возраст:")
        return
    await state.update_data(age=int(message.text))
    await Form.next()
    await message.reply("Введите ваш рост в см:", reply_markup=cancel_keyboard)

@dp.message_handler(state=Form.height)
async def process_height(message: types.Message, state: FSMContext):
    if not message.text.isdigit() or not (50 <= int(message.text) <= 250):
        await message.reply("❌ Рост должен быть числом от 50 до 250. Введите ваш рост в см:")
        return
    await state.update_data(height=int(message.text))
    await Form.next()
    await message.reply("Введите ваш вес в кг:", reply_markup=cancel_keyboard)

@dp.message_handler(state=Form.weight)
async def process_weight(message: types.Message, state: FSMContext):
    if not message.text.isdigit() or not (20 <= int(message.text) <= 300):
        await message.reply("❌ Вес должен быть числом от 20 до 300. Введите ваш вес в кг:")
        return
    await state.update_data(weight=int(message.text))
    await Form.next()
    await message.reply("Выберите ваш образ жизни:", reply_markup=lifestyle_keyboard)

@dp.message_handler(state=Form.lifestyle)
async def process_lifestyle(message: types.Message, state: FSMContext):
    if message.text not in ['Сидячий', 'Малоактивный', 'Активный', 'Очень активный']:
        await message.reply("❌ Пожалуйста, выберите образ жизни, используя кнопки ниже.")
        return
    await state.update_data(lifestyle=message.text)
    await Form.next()
    await message.reply("Выберите вашу цель:", reply_markup=goal_keyboard)

@dp.message_handler(state=Form.goal)
async def calculate_bju(message: types.Message, state: FSMContext):
    if message.text not in ['Сбросить вес', 'Набрать вес', 'Поддерживать вес']:
        await message.reply("❌ Пожалуйста, выберите цель, используя кнопки ниже.")
        return
    await state.update_data(goal=message.text)
    user_data = await state.get_data()

    bmr = 0
    if user_data['gender'] == 'Мужской':
        bmr = 88.36 + (13.4 * user_data['weight']) + (4.8 * user_data['height']) - (5.7 * user_data['age'])
    else:
        bmr = 447.6 + (9.2 * user_data['weight']) + (3.1 * user_data['height']) - (4.3 * user_data['age'])

    activity_multiplier = {
        'Сидячий': 1.2,
        'Малоактивный': 1.375,
        'Активный': 1.55,
        'Очень активный': 1.725
    }[user_data['lifestyle']]

    tdee = bmr * activity_multiplier

    if user_data['goal'] == 'Сбросить вес':
        tdee *= 0.85
    elif user_data['goal'] == 'Набрать вес':
        tdee *= 1.15

    protein = user_data['weight'] * 1.8
    fat = tdee * 0.25 / 9
    carbs = (tdee - (protein * 4) - (fat * 9)) / 4

    await message.reply(f"Ваши ежедневные потребности в БЖУ:\n"
                        f"Калории: {int(tdee)} ккал\n"
                        f"Белки: {int(protein)} г\n"
                        f"Жиры: {int(fat)} г\n"
                        f"Углеводы: {int(carbs)} г", reply_markup=main_menu_keyboard)

    await state.finish()

@dp.message_handler(content_types=types.ContentType.ANY, state="*")
async def handle_invalid_message(message: types.Message):
    if message.content_type != types.ContentType.TEXT:
        await message.reply("Пожалуйста, введите текстовое сообщение.")

if __name__ == '__main__':
    init_db()  # Убедимся, что база данных инициализирована
    dp.loop.create_task(schedule_reminders())
    executor.start_polling(dp, skip_updates=True)
